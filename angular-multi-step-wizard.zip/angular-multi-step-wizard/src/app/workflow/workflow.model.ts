export const STEPS = {
    personal: 'personal',
    work: 'work',
    address: 'address',
    result: 'result'
}
